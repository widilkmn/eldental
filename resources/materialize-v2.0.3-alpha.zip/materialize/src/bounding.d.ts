export declare class Bounding {
    left: number;
    top: number;
    width: number;
    height: number;
}
//# sourceMappingURL=bounding.d.ts.map